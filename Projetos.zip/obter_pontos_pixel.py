from PIL import Image


def obter_pontos_computador():

    imagem = Image.open("D:\\Projeto INT\\INT\\circulo.png")


    pixels = imagem.load()

    # Definição da cor a ser armazenada
    cor_desejada = (0, 0, 0)  



    largura, altura = imagem.size

    #Lista onde será armazenada o x e y da cor escolhida.
    pontos_cor_desejada = []


    for x in range(largura):
        for y in range(altura):
        
            cor = pixels[x, y]
        
            if cor == cor_desejada:
            
                pontos_cor_desejada.append([x, y, 9999])


    for ponto in pontos_cor_desejada:
        print("Ponto de cor desejada:", ponto)


def obter_pontos_usuario():

    imagem = Image.open("D:\\Projeto INT\\INT\\testando.png")


    pixels = imagem.load()

    # Definição da cor a ser armazenada
    cor_desejada = (0, 0, 0)  



    largura, altura = imagem.size

    #Lista onde será armazenada o x e y da cor escolhida.
    pontos_cor_desejada = []


    for x in range(largura):
        for y in range(altura):
        
            cor = pixels[x, y]
        
            if cor == cor_desejada:
            
                pontos_cor_desejada.append([x, y, 9999])


    for ponto in pontos_cor_desejada:
        print("Ponto de cor desejada:", ponto)




#if par x y do computador deve achar o par x y do usuario e mudar o valor da distancia em ambos


# X+0, Y+0     Distancia=0


#se par x y do computador deve achar o par x y do usuario, mude o valor da distancia em ambos e finalizar a pesquisa para o par
# X+0, Y-1     Distancia=1    Norte
# X+0, Y+1     Distancia=1    Sul
# X+1, Y+0     Distancia=1    Leste
# X-1, Y+0     Distancia=1    Oeste
# X+1, Y+1     Distancia=1    Sudeste
# X-1, Y-1     Distancia=1    Noroeste
# X-1, Y+1     Distancia=1    Sudoeste
# X+1, Y-1     Distancia=1    Nordeste

def atualizar_distancia(lista_coords_computador, lista_coords_usuario):
    # Lista de movimentos possíveis com a respectiva nova coordenada
    movimentos = [
        (0, -1),   # Norte
        (0, 1),    # Sul
        (1, 0),    # Leste
        (-1, 0),   # Oeste
        (1, 1),    # Sudeste
        (-1, -1),  # Noroeste
        (-1, 1),   # Sudoeste
        (1, -1)    # Nordeste
    ]

    for coord_computador in lista_coords_computador:
        x_comp, y_comp, _ = coord_computador
        
        # Verificar cada coordenada do usuário
        for coord_usuario in lista_coords_usuario:
            x_user, y_user = coord_usuario
            
            # Verificar cada movimento
            for dx, dy in movimentos:
                novo_x = x_comp + dx
                novo_y = y_comp + dy
                
                # Se a nova coordenada coincide com a do usuário, a distância é 1
                if (novo_x, novo_y) == (x_user, y_user):
                    coord_computador[2] = 1
                    break

# Exemplo de uso
lista_coords_computador = [
    [3, 3, 9999],
    [5, 5, 9999],
    [8, 8, 9999]
]
lista_coords_usuario = [
    (4, 2),
    (5, 6),
    (9, 9)
]

atualizar_distancia(lista_coords_computador, lista_coords_usuario)
print(f"As coordenadas e as distâncias são: {lista_coords_computador}")