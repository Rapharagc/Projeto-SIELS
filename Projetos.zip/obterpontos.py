"""

programa="guarda_simplificapixels.py"

caminho = "C:\\Saul_PeriodoCorona_08-04-2021_em05-06-2022\\Cursos\\EstudoPython\\"

exec(open(caminho+programa).read())

"""

#[https://pillow.readthedocs.io/en/stable/handbook/tutorial.html]

#[https://www.w3schools.com/colors/colors_picker.asp]

from PIL import Image # Python Imaging Library (PIL)

import random

import math

import io

caminho = "C:\\Saul_PeriodoCorona_08-04-2021_em05-06-2022\\Cursos\\EstudoPython\\"

 

 

def obtercircunferencia(caminho, arquivofigura, r_escolhida, g_escolhida, b_escolhida):

  imagem = Image.open(caminho+'imagemvazia.jpg')

  pix = imagem.load()

  #print ("size: ",imagem.size)

  angulo_graus = 0

  while angulo_graus<=360:

    angulo_rad = angulo_graus*(3.1416/180)

    x = abs(200+int(100*math.sin(angulo_rad)))

    y = abs(200+int(100*math.cos(angulo_rad)))

    #pix[x,y] = (r_escolhida,g_escolhida,b_escolhida,0)

    imagem.putpixel( (x, y), (r_escolhida,g_escolhida,b_escolhida))

    angulo_graus=angulo_graus+0.01

  imagem.save(caminho+arquivofigura)

  return imagem

 

 

 

def obterlistadepontos(arquivofigura,r_busca, g_busca, b_busca):

  listadepontos = []

  print(arquivofigura)

  im = Image.open(arquivofigura)

  pix = im.load()

  print ("size: ",im.size)

  r=0

  g=0

  b=0

  x=0

  while x < im.size[0]:

    y=0

    while y < im.size[1]:

      r=pix[x,y][0]

      g=pix[x,y][1]

      b=pix[x,y][2]

      #print(x,y,r,g,b)

      #if (x>=470 and y<=265 and x<=694 and y>=30 and r_busca==0 and g_busca==0 and b_busca==0):

      if (r>0 and g>0 and b>0 and r<255 and g<255 and b<255 ):

        print(x,y,r,g,b)

      #if (r==r_busca and g==g_busca and b==b_busca):

      if (r!=r_busca and g==0 and b==0):

        #print(x,y,r,g,b)

        listadepontos.append([x,y])

        #pix[x,y] = (r,g,b,0)

      y=y+1

    x=x+1

  return listadepontos

 

 

def percentual_de_elementos_dalista1_encontrados_nalista2(lista1, lista2):

  total_elementos = 0

  total_elementos_encontrados = 0

  for coordenadas in lista1:

    total_elementos = total_elementos + 1

    try:

      posicaoencontrado = lista2.index(coordenadas)

      #print(x,posicaoencontrado)

      total_elementos_encontrados = total_elementos_encontrados + 1

    except:

      z=0 #print(x,"nao encontrado")

  percentual_elementos_encontrados = 100*total_elementos_encontrados/total_elementos

  return percentual_elementos_encontrados

 

caminho = "C:\\Saul_PeriodoCorona_08-04-2021_em05-06-2022\\Cursos\\EstudoPython\\"

arquivofigura_circunferencia = "figura_circunferencia_original.jpg"

obtercircunferencia(caminho, arquivofigura_circunferencia, 255, 0, 0).show()

    

listaoriginal = obterlistadepontos(caminho+arquivofigura_circunferencia, 255, 0, 0)

print("listaoriginal: ", listaoriginal, len(listaoriginal))

 

 

arquivovaziotiff = "vazio.tif"

listaoriginal = obterlistadepontos(caminho+arquivovaziotiff, 255, 0, 0)

 

""" 

 

listamanual = obterlistadepontos(caminho+'manual.jpg',0,0,0)

 

 

 

percentual_encontrado_dalistaoriginal_nalistamanual = percentual_de_elementos_dalista1_encontrados_nalista2(listaoriginal, listamanual)

percentual_encontrado_dalistamanual_nalistaoriginal = percentual_de_elementos_dalista1_encontrados_nalista2(listamanual, listaoriginal)

print(f"percentual_encontrado_dalistaoriginal_nalistamanual:{percentual_encontrado_dalistaoriginal_nalistamanual:,.2f}")

print(f"percentual_encontrado_dalistamanual_nalistaoriginal:{percentual_encontrado_dalistamanual_nalistaoriginal:,.2f}")

"""

 

"""

 

listaoriginal = obterlistadepontos(caminho+'figuraoriginal.jpg',0,0,0)

#listamanual = obterlistadepontos(caminho+'figurasegmentada.jpg',0,0,0)

#listamanual = obterlistadepontos(caminho+'figuramanual.jpg',0,0,0)

#listamanual = obterlistadepontos(caminho+'figuramanualfalhada.jpg',0,0,0)

#listamanual = obterlistadepontos(caminho+'figuramanualmuitofalhada.jpg',0,0,0)

listamanual = obterlistadepontos(caminho+'figuramanual_05-01-2024_14h42min.jpg',0,0,0)

 

"""