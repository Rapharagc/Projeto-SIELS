#tracasenoide_multiplassomas.py

import math
import matplotlib.pyplot as plt

def tracasenoide(x_inicial, x_final, fatorampliacao, fatoraceleracao):
  lista = []
  x=x_inicial
  while x < x_final:
    y = fatorampliacao*math.sin(x*fatoraceleracao)
    lista.append([x,y])
    x=x+0.1
  return lista


def somamultiplassenoides(listafatorampliacao_fatoraceleracao):
  x_inicial = 0
  x_final = 6.28
  listademultiplassenoides = []
  for elemento in listafatorampliacao_fatoraceleracao:
    fatorampliacao = elemento[0]
    fatoraceleracao = elemento[1]
    print("fatorampliacao=", fatorampliacao, "  fatoraceleracao=", fatoraceleracao)
    listademultiplassenoides.append(tracasenoide(x_inicial, x_final, fatorampliacao, fatoraceleracao))
  return listademultiplassenoides

def imprimirsomamultiplassenoides(listademultiplassenoides):
  deslocamento=40
  escala=20
  i = 0
  while i < len(listademultiplassenoides[1]):
    valor = listademultiplassenoides[0][i][1]+listademultiplassenoides[1][i][1]+listademultiplassenoides[2][i][1]+listademultiplassenoides[3][i][1]+listademultiplassenoides[4][i][1]
    print (" "*int(deslocamento+escala*valor)+"*")
    i = i + 1


listafatorampliacao_fatoraceleracao = [[1,1],[0.5,2],[0.3,4],[0.1,8],[0.05,16]]
listademultiplassenoides = somamultiplassenoides(listafatorampliacao_fatoraceleracao)
imprimirsomamultiplassenoides(listademultiplassenoides)

listafatorampliacao_fatoraceleracao = [[1,1],[0.4,4],[0.3,8],[0.1,16],[0.05,32]]
listademultiplassenoides = somamultiplassenoides(listafatorampliacao_fatoraceleracao)
imprimirsomamultiplassenoides(listademultiplassenoides)

listafatorampliacao_fatoraceleracao = [[1,1],[1/3,3],[1/5,5],[1/7,7],[1/9,9]]
listademultiplassenoides = somamultiplassenoides(listafatorampliacao_fatoraceleracao)
imprimirsomamultiplassenoides(listademultiplassenoides)

plt.plot(listafatorampliacao_fatoraceleracao)
plt.show()