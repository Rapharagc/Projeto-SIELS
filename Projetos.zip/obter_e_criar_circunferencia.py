from PIL import Image 
import random
import math
import io

caminho = "D:\\Projeto INT\\INT\\"


def obtercircunferencia(caminho, arquivofigura, r_escolhida, g_escolhida, b_escolhida):

  imagem = Image.open(caminho+'imagemvazia.jpg')

  pix = imagem.load()

  #print ("size: ",imagem.size)

  angulo_graus = 0

  lista = []

  while angulo_graus<=360:

    angulo_rad = angulo_graus*(3.1416/180)

    x = abs(200+int(100*math.sin(angulo_rad)))

    y = abs(200+int(100*math.cos(angulo_rad)))

    lista.append([x,y]) 

  imagem.save(caminho+arquivofigura)

  return imagem

  obtercircunferencia()