from PIL import Image

def obter_pontos_computador():
    imagem = Image.open("D:\\Projeto INT\\INT\\circulo.png")
    pixels = imagem.load()
    cor_desejada = (0, 0, 0)
    largura, altura = imagem.size
    pontos_cor_desejada = []

    for x in range(largura):
        for y in range(altura):
            cor = pixels[x, y]
            if cor == cor_desejada:
                pontos_cor_desejada.append([x, y, 9999])
    
    return pontos_cor_desejada

def obter_pontos_usuario():
    imagem = Image.open("D:\\Projeto INT\\INT\\testando.png")
    pixels = imagem.load()
    cor_desejada = (50, 205, 50)
    largura, altura = imagem.size
    pontos_cor_desejada = []

    for x in range(largura):
        for y in range(altura):
            cor = pixels[x, y]
            if cor == cor_desejada:
                pontos_cor_desejada.append((x, y))
    
    return pontos_cor_desejada

def atualizar_distancia(lista_coords_computador, lista_coords_usuario):
    movimentos = [
        (0, -1),   # Norte
        (0, 1),    # Sul
        (1, 0),    # Leste
        (-1, 0),   # Oeste
        (1, 1),    # Sudeste
        (-1, -1),  # Noroeste
        (-1, 1),   # Sudoeste
        (1, -1)    # Nordeste
    ]

    for coord_computador in lista_coords_computador:
        x_comp, y_comp, _ = coord_computador
        proximo = False
        
        for coord_usuario in lista_coords_usuario:
            x_user, y_user = coord_usuario
            
            for dx, dy in movimentos:
                novo_x = x_comp + dx
                novo_y = y_comp + dy
                
                if (novo_x, novo_y) == (x_user, y_user):
                    coord_computador[2] = 1
                    proximo = True
                    break
            if proximo:
                break

def calcular_porcentagem(lista_coords_computador):
    total_pontos = len(lista_coords_computador)
    pontos_corretos = sum(1 for ponto in lista_coords_computador if ponto[2] <= 1)
    porcentagem = (pontos_corretos / total_pontos) * 100
    return porcentagem


lista_coords_computador = obter_pontos_computador()
lista_coords_usuario = obter_pontos_usuario()

atualizar_distancia(lista_coords_computador, lista_coords_usuario)


for ponto in lista_coords_computador:
    print("Ponto do computador atualizado:", ponto)


porcentagem = calcular_porcentagem(lista_coords_computador)
print(f"Porcentagem do traçado do desenho do usuário é: {porcentagem:.2f}%")

