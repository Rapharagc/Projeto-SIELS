from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk, ImageGrab

def salvar_imagem():
   global img
   # Obtém as coordenadas e o tamanho do canvas
   x = canvas.winfo_rootx()
   y = canvas.winfo_rooty()
   width = canvas.winfo_width()
   height = canvas.winfo_height()
    
   # Captura a área específica do canvas e salva a imagem
   ImageGrab.grab(bbox=(x, y, x + width, y + height)).save("D:\\Projeto INT\\INT\\testando.png")


   #img.save("C:\\Saul_PeriodoCorona_08-04-2021_em05-06-2022\\Cursos\\EstudoPython\\teste.png")
   #ImageGrab.grab().crop((x, y, x1, y1)).save("C:\\Saul_PeriodoCorona_08-04-2021_em05-06-2022\\Cursos\\EstudoPython\\teste.png")
   
def draw_line(event):
   global click_num
   global x1,y1
   #if click_num==0:   
   if click_num%2==0:
      x1=event.x
      y1=event.y
      click_num=1
   else:
      x2=event.x
      y2=event.y
   #canvas.create_line(x1,y1,x2,y2, fill="green", width=10)
   #canvas.create_line(x1,y1,x1+1,y1+1, fill="green", width=1)
   #canvas.create_line(x1, y1, x1+2, y1+2, fill="#32CD32", width=3)
   for i in range(-1,2):
      for j in range(-1,2):
         canvas.create_line(x1, y1, x1+i, y1+j, fill="#32CD32", width=3)
   click_num = click_num + 1 

def obter_pontos_computador():
    imagem = Image.open("D:\\Projeto INT\\INT\\circulo.png")
    pixels = imagem.load()
    cor_desejada = (0, 0, 0)
    largura, altura = imagem.size
    pontos_cor_desejada = []

    for x in range(largura):
        for y in range(altura):
            cor = pixels[x, y]
            if cor == cor_desejada:
                pontos_cor_desejada.append([x, y, 9999])
    
    return pontos_cor_desejada

def obter_pontos_usuario():
    imagem = Image.open("D:\\Projeto INT\\INT\\testando.png")
    pixels = imagem.load()
    cor_desejada = (50, 205, 50)
    largura, altura = imagem.size
    pontos_cor_desejada = []

    for x in range(largura):
        for y in range(altura):
            cor = pixels[x, y]
            if cor == cor_desejada:
                pontos_cor_desejada.append((x, y))
    
    return pontos_cor_desejada

def atualizar_distancia(lista_coords_computador, lista_coords_usuario):
    movimentos = [
        (0, -1),   # Norte
        (0, 1),    # Sul
        (1, 0),    # Leste
        (-1, 0),   # Oeste
        (1, 1),    # Sudeste
        (-1, -1),  # Noroeste
        (-1, 1),   # Sudoeste
        (1, -1)    # Nordeste
    ]

    for coord_computador in lista_coords_computador:
        x_comp, y_comp, _ = coord_computador
        proximo = False
        
        for coord_usuario in lista_coords_usuario:
            x_user, y_user = coord_usuario
            
            for dx, dy in movimentos:
                novo_x = x_comp + dx
                novo_y = y_comp + dy
                
                if (novo_x, novo_y) == (x_user, y_user):
                    coord_computador[2] = 1
                    proximo = True
                    break
            if proximo:
                break

def calcular_porcentagem(lista_coords_computador):
    total_pontos = len(lista_coords_computador)
    pontos_corretos = sum(1 for ponto in lista_coords_computador if ponto[2] <= 1)
    porcentagem = (pontos_corretos / total_pontos) * 100
    return porcentagem


def resultado():
    salvar_imagem()
    lista_coords_computador = obter_pontos_computador()
    lista_coords_usuario = obter_pontos_usuario()

    atualizar_distancia(lista_coords_computador, lista_coords_usuario)


    for ponto in lista_coords_computador:
        print("Ponto do computador atualizado:", ponto)


    porcentagem = calcular_porcentagem(lista_coords_computador)
    print(f"Porcentagem do traçado do desenho do usuário é: {porcentagem:.2f}%")
    label_2.config(text=f"Porcentagem do traçado do desenho do usuário é: {porcentagem:.2f}%")

janela=Tk()
janela.geometry("800x600")
canvas=Canvas(janela, width=800, height=500, background="white")
canvas.grid(row=0, column=0)
frame_principal =Frame(janela)
frame_principal.grid(row=1, column=0)
label_1 = Label(frame_principal, text="Teste")
label_1.pack()
botao_1 = Button(frame_principal, text="Salvar", command=resultado)
botao_1.pack()
label_2 = Label(frame_principal, text='')
label_2.pack()
#canvas.bind('<Button-3>', salvar_imagem) 
canvas.bind('<B1-Motion>', draw_line)
click_num=0

img= PhotoImage(file = "D:\\Projeto INT\\INT\\circulo.png") #ppm, gif, png
canvas.create_image(0,0, anchor=NW, image=img)
#print (img.getpixel(self, 10,10))

janela.mainloop()