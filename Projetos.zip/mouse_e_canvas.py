#https://www.tutorialspoint.com/drawing-a-line-between-two-mouse-clicks-using-tkinter
#https://tkinter-docs.readthedocs.io/en/latest/widgets/canvas.html
#https://python-course.eu/tkinter/events-and-binds-in-tkinter.php
#https://python-course.eu/tkinter/canvas-widgets-in-tkinter.php
#https://www.tutorialspoint.com/python/tk_anchors.htm
#https://copyprogramming.com/howto/tkinter-canvas-item-configure#tkinter-save-canvas-and-load

"""
programa="mouse_e_canvas.py"
caminho = "C:\\Saul_PeriodoCorona_08-04-2021_em05-06-2022\\Cursos\\EstudoPython\\" 
exec(open(caminho+programa).read())
"""

from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk, ImageGrab

def salvar_imagem(event):
   global img
   # Obtém as coordenadas e o tamanho do canvas
   x = canvas.winfo_rootx()
   y = canvas.winfo_rooty()
   width = canvas.winfo_width()
   height = canvas.winfo_height()
    
   # Captura a área específica do canvas e salva a imagem
   ImageGrab.grab(bbox=(x, y, x + width, y + height)).save("D:\\Projeto INT\\INT\\testando.png")


   #img.save("C:\\Saul_PeriodoCorona_08-04-2021_em05-06-2022\\Cursos\\EstudoPython\\teste.png")
   #ImageGrab.grab().crop((x, y, x1, y1)).save("C:\\Saul_PeriodoCorona_08-04-2021_em05-06-2022\\Cursos\\EstudoPython\\teste.png")
   
def draw_line(event):
   global click_num
   global x1,y1
   #if click_num==0:   
   if click_num%2==0:
      x1=event.x
      y1=event.y
      click_num=1
   else:
      x2=event.x
      y2=event.y
   #canvas.create_line(x1,y1,x2,y2, fill="green", width=10)
   #canvas.create_line(x1,y1,x1+1,y1+1, fill="green", width=1)
   #canvas.create_line(x1, y1, x1+2, y1+2, fill="#32CD32", width=3)
   for i in range(-1,2):
      for j in range(-1,2):
         canvas.create_line(x1, y1, x1+i, y1+j, fill="#32CD32", width=3)
   click_num = click_num + 1 

janela=Tk()
janela.geometry("800x600")
canvas=Canvas(janela, width=800, height=600, background="white")
canvas.grid(row=0, column=0)
canvas.bind('<Button-3>', salvar_imagem) 
canvas.bind('<B1-Motion>', draw_line)
click_num=0

img= PhotoImage(file = "D:\\Projeto INT\\INT\\circulo.png") #ppm, gif, png
canvas.create_image(0,0, anchor=NW, image=img)
#print (img.getpixel(self, 10,10))

janela.mainloop()



#Traçar linha em todos os sentidos       
#canvas.create_line(x1, y1, x1+0, y1+0, fill="#32CD32", width=3)
#canvas.create_line(x1, y1, x1+1, y1+0, fill="#32CD32", width=3)
#canvas.create_line(x1, y1, x1+0, y1+1, fill="#32CD32", width=3)
#canvas.create_line(x1, y1, x1+1, y1+1, fill="#32CD32", width=3)

#canvas.create_line(x1, y1, x1-1, y1+0, fill="#32CD32", width=3)
#canvas.create_line(x1, y1, x1+0, y1-1, fill="#32CD32", width=3)
#canvas.create_line(x1, y1, x1-1, y1-1, fill="#32CD32", width=3)

#canvas.create_line(x1, y1, x1+1, y1-1, fill="#32CD32", width=3)
#canvas.create_line(x1, y1, x1-1, y1+1, fill="#32CD32", width=3)
