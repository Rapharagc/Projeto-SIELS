import tkinter as tk
from PIL import Image, ImageDraw, ImageChops, ImageTk

#Criando duas imagens idênticas
imagem_original = Image.new("RGB", (300, 200), color="white")
imagem_modificada = imagem_original.copy()

#Desenhando algumas diferenças sutis na segunda imagem
draw = ImageDraw.Draw(imagem_modificada)
draw.rectangle([50, 50, 70, 70], fill="red")  # Diferença 1
draw.line([(100, 100), (120, 120)], fill="blue", width=2)  # Diferença 2

# Salvando as imagens
imagem_original.save("imagem_original.png")
imagem_modificada.save("imagem_modificada.png")

#Função para comparar as imagens e encontrar as diferenças, usando o ImageChops
def encontrar_diferencas(imagem1, imagem2):
    diff = ImageChops.difference(imagem1, imagem2)
    bbox = diff.getbbox()
    return bbox

#Carregando as imagens
imagem_original = Image.open("imagem_original.png")
imagem_modificada = Image.open("imagem_modificada.png")

#Encontrando as diferenças
diferencas = encontrar_diferencas(imagem_original, imagem_modificada)


root = tk.Tk()
root.title("Encontre as Diferenças")

#Convertendo as imagens para o formato usado pelo tkinter
imagem_original_tk = ImageTk.PhotoImage(imagem_original)
imagem_modificada_tk = ImageTk.PhotoImage(imagem_modificada)

#Função que marca quando o espaço da segunda for diferente da primeira imagem
def on_click(event):
    x, y = event.x, event.y
    if diferencas:
        x0, y0, x1, y1 = diferencas
        if x0 <= x <= x1 and y0 <= y <= y1:
            draw_circle(x, y)
        else:
            draw_x(x, y)

#Desenha um Circulo verde
def draw_circle(x, y):
    draw = ImageDraw.Draw(imagem_modificada)
    radius = 10
    draw.ellipse((x - radius, y - radius, x + radius, y + radius), outline="green", width=3)
    # Atualizando a imagem no tkinter
    imagem_modificada_tk.paste(imagem_modificada)
    label_modificada.config(image=imagem_modificada_tk)

#Desenha um X vermelho
def draw_x(x, y):
    draw = ImageDraw.Draw(imagem_modificada)
    size = 10
    draw.line((x - size, y - size, x + size, y + size), fill="red", width=3)
    draw.line((x - size, y + size, x + size, y - size), fill="red", width=3)
    # Atualizando a imagem no tkinter
    imagem_modificada_tk.paste(imagem_modificada)
    label_modificada.config(image=imagem_modificada_tk)


label_original = tk.Label(root, image=imagem_original_tk)
label_original.pack(side="left", padx=10, pady=10)

label_modificada = tk.Label(root, image=imagem_modificada_tk)
label_modificada.pack(side="right", padx=10, pady=10)


label_modificada.bind("<Button-1>", on_click)


root.mainloop()