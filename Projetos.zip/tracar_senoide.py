import math

def tracasenoide(x_inicial, x_final, fatorampliacao, fatoraceleracao):
  lista = []
  x=x_inicial
  while x < x_final:
    y = fatorampliacao*math.sin(x*fatoraceleracao)
    lista.append([x,y])
    x=x+0.1
  return lista

x_inicial = 0
x_final = 6.28
lista_1=tracasenoide(x_inicial, x_final, 1,1)
lista_2=tracasenoide(x_inicial, x_final, 0.5,2)
lista_3=tracasenoide(x_inicial, x_final, 0.3,4)
lista_4=tracasenoide(x_inicial, x_final, 0.1,8)
lista_5=tracasenoide(x_inicial, x_final, 0.05,16)
deslocamento=40
escala=20
i = 0
while i < len(lista_1):
  #valor = lista_1[i][1]+lista_2[i][1]+lista_3[i][1]+lista_4[i][1]+lista_5[i][1]
  valor = lista_1[i][1]
  print (" "*int(deslocamento+escala*valor)+"*")
  i = i + 1

